#!/bin/bash

while [ 1 -eq 1 ] ; do
	du
done

